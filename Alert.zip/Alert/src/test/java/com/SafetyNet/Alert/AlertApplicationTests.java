package com.SafetyNet.Alert;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlertApplicationTests {

	@Test
	void contextLoads() {
	}

}
